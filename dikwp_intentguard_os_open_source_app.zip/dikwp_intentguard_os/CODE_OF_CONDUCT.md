# Code of Conduct

This project follows a research-first and safety-first norm. Contributors should avoid deception, harassment, hidden surveillance, unsafe autonomy, and claims that exceed available evidence.
