# Integration Guide

## Minimal Python integration

```python
from dikwp_intentguard import analyze

payload = {
    "actor": "research_agent",
    "system_purpose": "Summarize papers without executing tools.",
    "user_intent": "Summarize this PDF.",
    "channel": "retrieved_doc",
    "text": "External PDF text...",
    "proposed_action": {"tool": "summarize", "target": "paper", "payload": "", "autonomy_level": 0}
}

result = analyze(payload).to_dict()
if result["decision"] == "allow":
    pass
elif result["decision"] == "review":
    send_to_reviewer(result)
else:
    block_action(result)
```

## Suggested agent framework integration points

- Before memory writes.
- Before tool calls.
- After retrieval and before prompt assembly.
- Before final output in regulated workflows.
- During incident replay.

## High-value use cases

- Customer support agents.
- Sales agents that send emails.
- Procurement agents that read vendor websites.
- Research agents that retrieve PDFs.
- Developer agents with access to repositories.
- Internal knowledge-base agents with PII exposure.
