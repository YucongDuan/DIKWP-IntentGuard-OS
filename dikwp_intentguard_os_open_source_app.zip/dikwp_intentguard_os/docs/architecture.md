# Architecture

```text
Input / Retrieved Content / Memory / Tool Proposal
        |
        v
DIKWP Parser ----> Evidence Ledger
        |
        v
P-Layer Intent Tuple: goal, value, constraint, time, feedback
        |
        v
Risk Signal Stack:
  - direct prompt injection
  - indirect prompt injection
  - memory poisoning
  - sensitive data exposure
  - tool overreach
  - excessive autonomy
  - source trust gap
  - intent drift
        |
        v
Policy Gate: allow / review / block
        |
        v
Replay Bundle + Recommended Actions
```

## Core modules

- `signals.py`: local risk-signal detection.
- `intent.py`: P-layer five-tuple extraction and continuity scoring.
- `dikwp.py`: DIKWP record generation.
- `policy.py`: policy-as-code thresholds.
- `evidence.py`: claim and source ledger.
- `guard.py`: unified orchestration.
- `cli.py`: command-line interface.
- `app.py`: optional FastAPI adapter.
- `static_audit.py`: source tree boundary audit.

## Design choice

The core runtime uses standard Python only. This makes the package easy to inspect, fork, install, and adapt. Production teams can wrap it with their own API gateway, SIEM, IAM, MCP, LangChain, AutoGen, CrewAI, or custom agent framework.
