# Open Source Launch Plan

## Repository

Suggested name: `dikwp-intentguard-os`

## First release message

DIKWP IntentGuard OS is an open-source intent firewall and evidence ledger for AI agents. It converts prompts, retrieved content, memory notes and proposed tool calls into DIKWP records, P-layer intent tuples, risk categories and replay bundles.

## Launch checklist

1. Publish repository with Apache-2.0 license.
2. Pin repository under the YucongDuan GitHub profile.
3. Add README screenshots and demo JSON outputs.
4. Publish a Chinese product article: “用 DIKWP 给 AI Agent 加一层意图防火墙”.
5. Invite AI security, agent-framework and governance contributors.
6. Add adapters for LangChain, AutoGen, CrewAI, MCP gateways and browser agents.
7. Publish enterprise template policies.
8. Create a DIKWP IntentGuard certification workshop.

## Benefit path

- Attribution via NOTICE and CITATION.
- Consulting around enterprise policy customization.
- Training around DIKWP Agent Governance.
- Paid hosted dashboard in a future commercial version.
- White-label deployments for enterprise AI safety teams.
