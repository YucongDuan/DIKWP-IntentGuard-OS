# DIKWP Mapping

## D / Data

Raw prompt, retrieved content, source snippets, memory note, proposed tool, target, payload, actor and channel metadata.

## I / Information

Source trust, channel type, instruction/data boundary, proposed action context, actor-to-tool relationship, evidence gap.

## K / Knowledge

Policy-as-code, known risk patterns, prompt-injection typology, least-privilege rule, agent workflow rules, memory governance.

## W / Wisdom

Safety, privacy, legal exposure, action reversibility, human approval boundary, evidence sufficiency, harm minimization.

## P / Purpose

Five-tuple: goal, value, constraint, time horizon and feedback loop. This is the distinctive DIKWP upgrade over simple prompt filtering.

## R / Reliability

Supported, Provisional, Borrowed, Contested, Blocked. Runtime reports explicitly mark local heuristics as provisional and deployment policy as borrowed reliability.
