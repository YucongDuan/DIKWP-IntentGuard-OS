# Landing Page Copy

## DIKWP IntentGuard OS

**Open-source intent firewall for AI agents.**

AI agents are no longer just answering questions. They read documents, write memories, call tools and act across enterprise systems. DIKWP IntentGuard OS gives every agent action a semantic audit layer before it reaches high-impact tools.

### What it does

- Finds prompt injection and indirect instructions.
- Detects intent drift and memory poisoning.
- Reviews high-autonomy tool calls.
- Creates DIKWP records and P-layer intent tuples.
- Produces evidence ledgers and replay bundles.

### Why DIKWP

DIKWP adds Purpose to the classic Data-Information-Knowledge-Wisdom chain. For AI agents, Purpose is not optional. It is the difference between answering a question and safely acting in the world.
