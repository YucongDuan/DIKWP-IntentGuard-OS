# Roadmap

## v0.1

- Local heuristic guard.
- CLI.
- Evidence ledger.
- P-layer five-tuple.
- Static boundary audit.

## v0.2

- LangChain and AutoGen adapters.
- MCP-style tool gateway adapter.
- Better multilingual prompt-injection dataset.
- Memory-write approval workflow.

## v0.3

- Browser-based dashboard.
- SIEM export.
- OpenTelemetry traces.
- Policy pack marketplace.

## v1.0

- Enterprise deployment guide.
- Benchmarks.
- Guardrail red-team suite.
- DIKWP Agent Governance certification materials.
