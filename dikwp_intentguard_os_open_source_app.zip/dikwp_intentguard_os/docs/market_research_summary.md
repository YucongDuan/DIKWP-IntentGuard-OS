# Market Research Summary

## Signal 1: agentic AI is moving into enterprise applications

Gartner predicts rapid integration of task-specific AI agents into enterprise applications. This creates a market for guardrails, oversight, and runtime decision controls.

## Signal 2: guardian agents are becoming a category

Gartner describes guardian agents as AI-based technologies that support trustworthy and secure interactions with AI by monitoring, redirecting, or blocking actions according to predefined goals.

## Signal 3: prompt injection is still a top risk

OWASP lists prompt injection as LLM01:2025 and notes that direct and indirect instructions can alter model behavior, including unauthorized access or actions in connected systems.

## Signal 4: public risk frameworks are now mature enough to map against

NIST AI RMF and the Generative AI Profile give organizations a governance vocabulary: Govern, Map, Measure, Manage, risk context, and risk treatment.

## Product conclusion

A small, inspectable, open-source DIKWP intent firewall can become a natural entry point for organizations that want to test agentic AI but are not ready to buy large proprietary AI security platforms.
