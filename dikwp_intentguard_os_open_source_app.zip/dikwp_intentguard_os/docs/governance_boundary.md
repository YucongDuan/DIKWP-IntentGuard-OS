# Governance Boundary

DIKWP IntentGuard OS is a defensive audit and gating tool.

It must not be used to:

- create hidden surveillance systems;
- bypass platform or enterprise controls;
- exfiltrate secrets;
- build persistent malware;
- simulate compliance while hiding risk;
- misrepresent heuristic decisions as formal proof;
- remove human review for high-impact decisions.

Recommended deployment boundary:

1. Start in report-only mode.
2. Move to review mode for high-risk actions.
3. Move to blocking mode only after false-positive calibration.
4. Keep replay bundles for incident review.
5. Keep final responsibility with accountable human and organizational roles.
