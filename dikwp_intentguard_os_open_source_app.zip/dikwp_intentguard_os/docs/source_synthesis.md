# Source Synthesis

This project synthesizes four lines:

1. DIKWP theory: Data, Information, Knowledge, Wisdom and Purpose.
2. Intent theory: goal, value, constraint, time and feedback.
3. Agentic AI security: prompt injection, indirect injection, tool overreach, memory poisoning and excessive autonomy.
4. Enterprise governance: evidence custody, replayability, policy gates and human review.

The product deliberately avoids unsafe functionality. It is a gate and ledger, not an executor.
