# GitHub Release Draft

## DIKWP IntentGuard OS v0.1.0

Open-source intent firewall and audit ledger for AI agents.

### Highlights

- Detects prompt injection and indirect prompt injection markers.
- Flags excessive autonomy and tool overreach.
- Converts agent requests into DIKWP semantic records.
- Extracts P-layer intent five-tuples.
- Generates evidence ledgers and replay bundles.
- Runs with standard Python only.

### Install

```bash
pip install -e .
dikwp-intentguard examples/injection_tool_request.json --policy configs/default_policy.json
```

### Attribution

This release is designed to support the DIKWP ecosystem and preserve attribution to Yucong Duan.
