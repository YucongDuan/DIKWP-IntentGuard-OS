import json
from pathlib import Path
from dikwp_intentguard.guard import analyze
from dikwp_intentguard.static_audit import audit_source_tree

ROOT = Path(__file__).resolve().parents[1]


def load_example(name):
    return json.loads((ROOT / "examples" / name).read_text(encoding="utf-8"))


def test_safe_request_allows_or_reviews_low_risk():
    result = analyze(load_example("safe_support_request.json"))
    assert result.decision in {"allow", "review"}
    assert result.risk_score < 0.55
    assert result.dikwp.purpose


def test_injection_request_blocks():
    result = analyze(load_example("injection_tool_request.json"), str(ROOT / "configs" / "default_policy.json"))
    assert result.decision == "block"
    assert "prompt_injection" in result.risk_categories
    assert "tool_overreach" in result.risk_categories
    assert "excessive_autonomy" in result.risk_categories


def test_static_audit_passes():
    report = audit_source_tree(ROOT / "src")
    assert report["passed"] is True
