# Contributing

Contributions are welcome in four areas:

1. New DIKWP policy templates.
2. Agent framework adapters.
3. Better benchmark datasets for prompt injection, memory poisoning, and intent drift.
4. Documentation and translations.

Pull requests should include tests, a short evidence ledger, and a clear statement of what the change does not prove.
