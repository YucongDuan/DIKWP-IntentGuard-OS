from __future__ import annotations

from typing import Dict, List
from .models import GuardDecision, GuardRequest, ProposedAction, SourceItem
from .signals import evaluate_signals
from .policy import decide, load_policy
from .dikwp import extract_dikwp
from .intent import extract_intent_tuple
from .evidence import build_evidence_ledger


def request_from_dict(data: Dict) -> GuardRequest:
    action_data = data.get("proposed_action") or {}
    sources_data = data.get("sources") or []
    return GuardRequest(
        actor=data.get("actor", "unknown"),
        text=data.get("text", ""),
        system_purpose=data.get("system_purpose", ""),
        user_intent=data.get("user_intent", ""),
        channel=data.get("channel", "user_prompt"),
        proposed_action=ProposedAction(**{k: v for k, v in action_data.items() if k in ProposedAction.__dataclass_fields__}),
        sources=[SourceItem(**{k: v for k, v in s.items() if k in SourceItem.__dataclass_fields__}) for s in sources_data],
        memory_notes=data.get("memory_notes", []),
        metadata=data.get("metadata", {}),
    )


def recommended_actions(decision: str, categories: List[str]) -> List[str]:
    base: List[str] = []
    if "prompt_injection" in categories or "indirect_prompt_injection" in categories:
        base += ["isolate instructions from untrusted content", "strip or quote external instructions", "require deterministic output validation"]
    if "tool_overreach" in categories or "excessive_autonomy" in categories:
        base += ["require explicit human approval", "downgrade tool scope", "use least-privilege credentials"]
    if "sensitive_data_exposure" in categories:
        base += ["redact secrets before model or tool execution", "rotate exposed credentials if real", "add secret scanning to ingestion"]
    if "memory_poisoning" in categories:
        base += ["do not write memory automatically", "separate user preference memory from policy memory", "require memory-review approval"]
    if "source_trust_gap" in categories:
        base += ["lower source trust", "cross-check with trusted source", "keep source text as data, not instruction"]
    if decision == "allow":
        base += ["log DIKWP record", "continue monitoring intent continuity"]
    elif decision == "review":
        base += ["send to reviewer with replay bundle", "block tool execution until review"]
    else:
        base += ["block action", "preserve forensic replay bundle", "open remediation ticket"]
    return list(dict.fromkeys(base))


def analyze(data: Dict, policy_path: str | None = None) -> GuardDecision:
    req = request_from_dict(data)
    policy = load_policy(policy_path)
    risk_score, cats, reasons = evaluate_signals(req, policy)
    # Intent discontinuity is not intrinsically harmful; it becomes a review signal when paired with action.
    intent_tuple = extract_intent_tuple(req)
    if intent_tuple.intent_continuity_score < 0.08 and req.proposed_action.tool != "none":
        cats = sorted(set(cats + ["intent_drift"]))
        reasons.append("Low overlap between system purpose and requested/proposed action")
        risk_score = round(min(1.0, risk_score + 0.12), 4)
    decision = decide(risk_score, policy)
    dikwp = extract_dikwp(req, cats)
    evidence = build_evidence_ledger(req, cats)
    replay_bundle = {
        "actor": req.actor,
        "channel": req.channel,
        "policy_name": policy.get("name"),
        "risk_score": risk_score,
        "risk_categories": cats,
        "decision": decision,
        "proposed_action": req.proposed_action.__dict__,
        "metadata": req.metadata,
    }
    return GuardDecision(decision, risk_score, cats, reasons, recommended_actions(decision, cats), dikwp, intent_tuple, evidence, replay_bundle)
