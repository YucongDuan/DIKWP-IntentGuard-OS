from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

DEFAULT_POLICY = {
    "name": "dikwp-intentguard-default",
    "review_threshold": 0.25,
    "block_threshold": 0.55,
    "max_autonomy_without_review": 1,
    "protected_terms": ["system prompt", "developer message", "api_key", "password", "token", "credential", "private key"],
    "high_impact_tools": ["shell", "database", "email", "payment", "deploy", "browser_write"],
}


def load_policy(path: str | None = None) -> Dict:
    if not path:
        return dict(DEFAULT_POLICY)
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Policy file not found: {path}")
    data = json.loads(p.read_text(encoding="utf-8"))
    policy = dict(DEFAULT_POLICY)
    policy.update(data)
    return policy


def decide(risk_score: float, policy: Dict) -> str:
    if risk_score >= float(policy.get("block_threshold", 0.55)):
        return "block"
    if risk_score >= float(policy.get("review_threshold", 0.25)):
        return "review"
    return "allow"
