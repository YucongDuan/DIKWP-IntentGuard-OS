from __future__ import annotations

from typing import List
from .models import EvidenceCard, GuardRequest
from .text_utils import excerpt


def build_evidence_ledger(req: GuardRequest, risk_categories: List[str]) -> List[EvidenceCard]:
    cards: List[EvidenceCard] = []
    cards.append(EvidenceCard(
        claim="The request text was evaluated by local DIKWP IntentGuard heuristics.",
        source="local_runtime",
        support=excerpt(req.text, 140),
        reliability="Supported / RunProof",
        gaps=["Heuristic evaluation is not a formal proof"],
    ))
    if req.system_purpose:
        cards.append(EvidenceCard(
            claim="A declared system purpose was supplied.",
            source="request.system_purpose",
            support=excerpt(req.system_purpose, 140),
            reliability="Solid / UserSupplied",
            gaps=[],
        ))
    for s in req.sources[:6]:
        cards.append(EvidenceCard(
            claim=f"Source {s.id} contributed context.",
            source=s.id,
            support=excerpt(s.text, 140),
            reliability="Borrowed / " + s.trust,
            gaps=["Source content may contain indirect instructions"] if s.trust in {"unknown", "low", "untrusted"} else [],
        ))
    for cat in risk_categories:
        cards.append(EvidenceCard(
            claim=f"Risk category detected: {cat}",
            source="signal_classifier",
            support="Pattern, policy, channel, or action-risk evidence matched this category.",
            reliability="Provisional / Heuristic",
            gaps=["Needs deployment-specific false-positive calibration"],
        ))
    return cards
