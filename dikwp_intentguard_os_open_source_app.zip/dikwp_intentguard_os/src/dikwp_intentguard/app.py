from __future__ import annotations

# Optional FastAPI adapter. The core library has no web dependency.
try:
    from fastapi import FastAPI
except Exception:  # pragma: no cover
    FastAPI = None

from .guard import analyze


def create_app():
    if FastAPI is None:
        raise RuntimeError("FastAPI is not installed. Install with: pip install fastapi uvicorn")
    app = FastAPI(title="DIKWP IntentGuard API", version="0.1.0")

    @app.post("/analyze")
    def analyze_endpoint(payload: dict):
        return analyze(payload).to_dict()

    @app.get("/health")
    def health():
        return {"status": "ok", "service": "dikwp-intentguard"}

    return app
