from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class SourceItem:
    id: str
    trust: str = "unknown"
    text: str = ""
    url: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class ProposedAction:
    tool: str = "none"
    target: str = "none"
    payload: str = ""
    autonomy_level: int = 0


@dataclass
class GuardRequest:
    actor: str
    text: str
    system_purpose: str
    user_intent: str = ""
    channel: str = "user_prompt"
    proposed_action: ProposedAction = field(default_factory=ProposedAction)
    sources: List[SourceItem] = field(default_factory=list)
    memory_notes: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DIKWPRecord:
    data: List[str]
    information: List[str]
    knowledge: List[str]
    wisdom: List[str]
    purpose: List[str]
    reliability: Dict[str, Any]


@dataclass
class IntentTuple:
    goals: List[str]
    values: List[str]
    constraints: List[str]
    time_horizon: str
    feedback: List[str]
    intent_continuity_score: float


@dataclass
class EvidenceCard:
    claim: str
    source: str
    support: str
    reliability: str
    gaps: List[str] = field(default_factory=list)


@dataclass
class GuardDecision:
    decision: str
    risk_score: float
    risk_categories: List[str]
    reasons: List[str]
    recommended_actions: List[str]
    dikwp: DIKWPRecord
    intent_tuple: IntentTuple
    evidence_ledger: List[EvidenceCard]
    replay_bundle: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
