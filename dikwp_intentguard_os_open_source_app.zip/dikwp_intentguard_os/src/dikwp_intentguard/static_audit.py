from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "subprocess", "paramiko", "ftplib", "telnetlib"}
FORBIDDEN_CALLS = {"system", "popen", "remove", "unlink", "rmtree", "exec", "eval"}


def audit_source_tree(root: str | Path) -> Dict:
    root = Path(root)
    findings: List[Dict] = []
    for py in root.rglob("*.py"):
        tree = ast.parse(py.read_text(encoding="utf-8"), filename=str(py))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split(".")[0] in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "name": alias.name})
            elif isinstance(node, ast.ImportFrom):
                mod = (node.module or "").split(".")[0]
                if mod in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(py), "type": "forbidden_import", "name": node.module})
            elif isinstance(node, ast.Call):
                name = None
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr
                if name in FORBIDDEN_CALLS:
                    findings.append({"file": str(py), "type": "forbidden_call", "name": name})
    return {"passed": not findings, "finding_count": len(findings), "findings": findings}


if __name__ == "__main__":
    import sys
    report = audit_source_tree(sys.argv[1] if len(sys.argv) > 1 else ".")
    print(json.dumps(report, ensure_ascii=False, indent=2))
