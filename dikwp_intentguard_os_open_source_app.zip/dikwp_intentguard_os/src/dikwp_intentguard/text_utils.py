from __future__ import annotations

import re
from typing import Iterable, List, Set

WORD_RE = re.compile(r"[A-Za-z0-9_\u4e00-\u9fff]+")

STOPWORDS = {
    "the", "and", "or", "to", "of", "a", "an", "in", "on", "for", "with", "as", "by", "is", "are", "was", "were",
    "this", "that", "it", "be", "from", "at", "我", "你", "他", "她", "它", "我们", "你们", "他们", "的", "了", "是", "在", "和", "与", "或", "为", "对", "把", "请", "不要"
}


def tokens(text: str) -> List[str]:
    return [m.group(0).lower() for m in WORD_RE.finditer(text or "")]


def keyword_set(text: str) -> Set[str]:
    return {t for t in tokens(text) if t not in STOPWORDS and len(t) > 1}


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))


def excerpt(text: str, length: int = 160) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= length else text[: length - 1] + "…"


def split_sentences(text: str) -> List[str]:
    parts = re.split(r"(?<=[。！？.!?])\s+|\n+", text or "")
    return [p.strip() for p in parts if p.strip()]
