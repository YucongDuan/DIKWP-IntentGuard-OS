from __future__ import annotations

from typing import List
from .models import GuardRequest, IntentTuple
from .text_utils import keyword_set, jaccard

VALUE_WORDS = ["safety", "privacy", "truth", "accuracy", "compliance", "security", "reliability", "安全", "隐私", "真实", "准确", "合规", "可靠"]
CONSTRAINT_WORDS = ["do not", "must not", "forbidden", "deny", "block", "limit", "without", "不要", "不得", "禁止", "限制", "未经"]
FEEDBACK_WORDS = ["monitor", "review", "audit", "feedback", "rollback", "observe", "check", "监测", "审核", "审计", "反馈", "回滚", "检查"]


def extract_intent_tuple(req: GuardRequest) -> IntentTuple:
    combined = " ".join([req.system_purpose, req.user_intent, req.text])
    lower = combined.lower()
    goals: List[str] = []
    if req.user_intent:
        goals.append(req.user_intent)
    if req.proposed_action.tool != "none":
        goals.append(f"execute proposed tool={req.proposed_action.tool} target={req.proposed_action.target}")
    if not goals:
        goals = ["understand and answer the request"]

    values = [w for w in VALUE_WORDS if w in lower]
    if not values:
        values = ["truthfulness", "safety", "auditability"]

    constraints = [w for w in CONSTRAINT_WORDS if w in lower]
    if req.proposed_action.autonomy_level >= 2:
        constraints.append("high-autonomy action requires review")
    if not constraints:
        constraints = ["least privilege", "evidence custody", "no hidden escalation"]

    time_horizon = "longitudinal" if any(x in lower for x in ["remember", "long", "persistent", "monitor", "长期", "持续", "记住", "监测"]) else "single-session"

    feedback = [w for w in FEEDBACK_WORDS if w in lower]
    if not feedback:
        feedback = ["audit log", "manual review when risk rises"]

    continuity = jaccard(keyword_set(req.system_purpose), keyword_set(req.user_intent + " " + req.proposed_action.payload))
    if not req.user_intent and not req.proposed_action.payload:
        continuity = 0.5
    return IntentTuple(goals, values, constraints, time_horizon, feedback, round(continuity, 4))
