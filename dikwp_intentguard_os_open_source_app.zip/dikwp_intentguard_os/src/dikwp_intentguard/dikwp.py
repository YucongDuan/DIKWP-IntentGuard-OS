from __future__ import annotations

from typing import Dict, List
from .models import DIKWPRecord, GuardRequest
from .text_utils import excerpt, split_sentences

DATA_MARKERS = ["metric", "data", "log", "timestamp", "id", "evidence", "source", "日志", "数据", "指标", "证据", "来源"]
INFO_MARKERS = ["relates", "depends", "difference", "context", "boundary", "关系", "差异", "边界", "语境", "上下文"]
KNOWLEDGE_MARKERS = ["policy", "rule", "procedure", "model", "method", "标准", "规则", "流程", "方法", "模型"]
WISDOM_MARKERS = ["risk", "harm", "privacy", "safety", "legal", "ethics", "风险", "伤害", "隐私", "安全", "合法", "伦理"]
PURPOSE_MARKERS = ["goal", "purpose", "intent", "objective", "mission", "目标", "目的", "意图", "为了", "任务"]


def _pick(sentences: List[str], markers: List[str], fallback: List[str]) -> List[str]:
    result = []
    for s in sentences:
        lower = s.lower()
        if any(m.lower() in lower for m in markers):
            result.append(excerpt(s, 180))
    return result[:5] or fallback[:3]


def extract_dikwp(req: GuardRequest, risk_categories: List[str]) -> DIKWPRecord:
    sentences = split_sentences(req.text)
    sources = [f"source:{s.id} trust={s.trust}" for s in req.sources]
    data = _pick(sentences, DATA_MARKERS, [excerpt(req.text), *sources])
    information = _pick(sentences, INFO_MARKERS, [f"channel={req.channel}", f"actor={req.actor}", f"action_tool={req.proposed_action.tool}"])
    knowledge = _pick(sentences, KNOWLEDGE_MARKERS, ["Policy-as-code evaluation", "DIKWP layer mapping", "Prompt-injection and intent-drift heuristics"])
    wisdom = _pick(sentences, WISDOM_MARKERS, ["Apply least privilege", "Separate evidence from instructions", "Escalate ambiguous high-impact actions"])
    purpose = _pick(sentences, PURPOSE_MARKERS, [req.system_purpose or "No system purpose supplied", req.user_intent or "No user intent supplied"])
    reliability: Dict[str, object] = {
        "level": "Supported" if risk_categories else "Provisional",
        "borrowed_from": ["local heuristics", "policy config", "source trust labels"],
        "residual": ["No model-internal ground truth", "Heuristic classifier only", "Requires deployment-specific calibration"],
    }
    return DIKWPRecord(data, information, knowledge, wisdom, purpose, reliability)
