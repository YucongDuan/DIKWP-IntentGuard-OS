from __future__ import annotations

import re
from typing import Dict, List, Tuple
from .models import GuardRequest

INJECTION_PATTERNS = [
    r"ignore (all )?(previous|above|prior) (instructions|rules)",
    r"disregard (all )?(previous|above|prior)",
    r"reveal (the )?(system|developer) (prompt|message|instructions)",
    r"bypass (safety|policy|guardrails|audit)",
    r"override (policy|system|developer)",
    r"you are now", r"act as if", r"jailbreak", r"prompt injection",
    r"忽略(之前|以上|所有)", r"无视(规则|约束|系统)", r"泄露(系统|开发者|提示词)", r"绕过(安全|审计|规则)", r"现在起你是", r"不要告诉(任何人|用户|管理员)",
]

SENSITIVE_PATTERNS = [
    r"(?i)api[_-]?key\s*[:=]\s*[A-Za-z0-9_\-]{12,}",
    r"(?i)(secret|token|password|passwd)\s*[:=]\s*\S+",
    r"(?i)bearer\s+[A-Za-z0-9._\-]{16,}",
    r"(?i)private key",
    r"\b\d{3}-\d{2}-\d{4}\b",
    r"\b(?:\d[ -]*?){13,16}\b",
]

TOOL_RISK_TERMS = [
    "delete", "drop", "send", "transfer", "deploy", "execute", "shell", "email", "payment", "database",
    "删除", "发送", "转账", "部署", "执行", "数据库", "付款"
]

MEMORY_POISON_TERMS = [
    "remember that", "store this", "永久记住", "以后都", "always trust", "永远相信", "system says"
]


def count_matches(patterns: List[str], text: str) -> List[str]:
    found = []
    for p in patterns:
        if re.search(p, text or "", re.IGNORECASE):
            found.append(p)
    return found


def evaluate_signals(req: GuardRequest, policy: Dict) -> Tuple[float, List[str], List[str]]:
    text = "\n".join([req.text, req.proposed_action.payload, "\n".join(req.memory_notes)])
    cats: List[str] = []
    reasons: List[str] = []
    score = 0.0

    inj = count_matches(INJECTION_PATTERNS, text)
    if inj:
        cats.append("prompt_injection")
        reasons.append(f"Prompt-injection markers detected: {len(inj)}")
        score += 0.32
    if req.channel in {"retrieved_doc", "external_web", "email", "tool_result"} and inj:
        cats.append("indirect_prompt_injection")
        reasons.append("Instruction-like content appeared in an external channel")
        score += 0.18

    sensitive = count_matches(SENSITIVE_PATTERNS, text)
    if sensitive:
        cats.append("sensitive_data_exposure")
        reasons.append(f"Potential sensitive data markers detected: {len(sensitive)}")
        score += 0.25

    action_text = f"{req.proposed_action.tool} {req.proposed_action.target} {req.proposed_action.payload}".lower()
    risky_tool_terms = [t for t in TOOL_RISK_TERMS if t in action_text]
    if req.proposed_action.tool not in {"none", "read", "search", "summarize"} and risky_tool_terms:
        cats.append("tool_overreach")
        reasons.append(f"Proposed action uses high-impact tool terms: {', '.join(risky_tool_terms[:4])}")
        score += 0.22
    if req.proposed_action.autonomy_level > int(policy.get("max_autonomy_without_review", 1)):
        cats.append("excessive_autonomy")
        reasons.append("Proposed autonomy level exceeds policy threshold")
        score += 0.16

    memory_hits = count_matches(MEMORY_POISON_TERMS, "\n".join(req.memory_notes) + "\n" + req.text)
    if memory_hits:
        cats.append("memory_poisoning")
        reasons.append("Memory-update language detected")
        score += 0.16

    protected = [p.lower() for p in policy.get("protected_terms", [])]
    if any(p in text.lower() for p in protected):
        cats.append("protected_context")
        reasons.append("Protected context terms were referenced")
        score += 0.08

    if req.sources and any(s.trust in {"unknown", "low", "untrusted"} for s in req.sources):
        cats.append("source_trust_gap")
        reasons.append("One or more sources have low or unknown trust")
        score += 0.08

    return round(min(score, 1.0), 4), sorted(set(cats)), reasons
