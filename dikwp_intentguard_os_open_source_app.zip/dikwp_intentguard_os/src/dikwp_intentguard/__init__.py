"""DIKWP IntentGuard OS: AI agent intent firewall and audit ledger."""

__version__ = "0.1.0"
from .guard import analyze
