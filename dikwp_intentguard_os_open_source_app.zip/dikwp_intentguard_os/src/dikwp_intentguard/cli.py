from __future__ import annotations

import argparse
import json
from pathlib import Path
from .guard import analyze


def main() -> int:
    parser = argparse.ArgumentParser(description="DIKWP IntentGuard: open-source AI agent intent firewall and audit ledger")
    parser.add_argument("input", help="JSON request file")
    parser.add_argument("--policy", help="Optional JSON policy file", default=None)
    parser.add_argument("--out", help="Output JSON file", default=None)
    args = parser.parse_args()
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    result = analyze(data, args.policy).to_dict()
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(text, encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
