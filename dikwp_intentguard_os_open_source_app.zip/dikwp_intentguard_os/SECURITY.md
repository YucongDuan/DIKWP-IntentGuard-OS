# Security Policy

Please report vulnerabilities privately before public disclosure. This project must not include exploit code, credential collection, persistence mechanisms, unsafe autonomous actions, or instructions for bypassing audit systems.

Security boundary: DIKWP IntentGuard OS evaluates and gates AI-agent requests. It does not execute high-impact tools by itself.
